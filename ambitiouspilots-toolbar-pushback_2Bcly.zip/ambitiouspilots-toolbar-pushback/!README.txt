Toolbar Pushback
Copyright (c) AmbitiousPilots 2024. All Rights Reserved. 
https://flightsim.to/file/15033/toolbar-pushback


## About:

Toolbar Pushback gives you full control over your pushback! Use Pushback Pre-Planning for automated 
pushback procedures, or take control yourself and steer the tug with your rudder pedals, joystick, 
keyboard or mouse and steplessly adjust the tug speed to your liking. All natively from within Flight 
Simulator without the need for running any apps or alt tabbing out of the sim. Additionally, ground 
services can be called with a click of a button. Works with all types of aircraft.

NOTE: This is the original freeware version of Toolbar Pushback by AmbitiousPilots. Ongoing development 
      has been moved to the payware add-on Toolbar Pushback Pro by Aerosoft GmbH. The freeware add-on 
      remains available on flightsim.to in its current state and will receive compatibility updates for 
      Microsoft Flight Simulator sim updates whenever possible. A feature comparison between the free- 
      and payware version of Toolbar Pushback can be found on: 

https://www.aerosoft.com/shop/flight/microsoft-flight-simulator/msfs-tools/4227/aerosoft-toolbar-pushback-pro


## Interactive Pushback Audio:

Please make sure the folder name of the add-on in the community directory equals 
"ambitiouspilots-toolbar-pushback". Please do not rename the folder. Also, when using 
add-on managers, these may rename the folder which would make it impossible for MSFS 
to find the required files. 

If you're using Microsoft Flight Simulator in any language other than English and want 
to use the Interactive Pushback Audio, please run the ENABLE_INTERACTIVE_AUDIO.bat file 
inside of this directory. This file will create symlinks to the English audio directory 
of Toolbar Pushback so MSFS will be able to access these audio files when set to another 
language. This is to keep the download size of the add-on small, instead of duplicating 
the files for every language, as symlinks cannot be included in a zip file on Windows. 

Note that the Interactive Pushback Audio is experimental. If something does not work and 
interrupts the pushback, you may disable this feature in the add-on options tab in order 
to proceed without the pushback audio.


## Changelog:

### Version 1.6.0 (December 20, 2024)
* UPDATED: Compatibility with MSFS2024.
* IMPROVED: Toolbar logic improvements.
* NOTE: No pushback tug interaction in MSFS2024 for the time being due to bug. Pushback itself works fine.

### Version 1.5.0 (July 1, 2024)
* FIXED: Pushback planner scroll wheel map zoom issue resolved.
* FIXED: Several add-on UI element positions adjusted.
* FIXED: Toolbar logic adapted to current MSFS version.
* FIXED: Pushback logic adjusted to Sim Update 15 changes.


### Version 1.4.1 (March 17, 2022)
* FIXED: Add-on panels are no longer resizable when closed. 
* FIXED: Possible incompatibility with other third party toolbar add-ons is resolved. 
* FIXED: FBW A32NX aft and cargo door buttons no longer swapped when using certain liveries. 
* IMPROVED: General performance improvements of the Pushback Planner. 
* ADDED: Door buttons in the aircraft tab for the new Aerosoft Twin Otter. 


### Version 1.4.0 (March 3, 2022)
* ADDED: Pushback Pre-Planning (public beta) for fully automated pushback procedures. 
* IMPROVED: Nosewheel Lift Simulation is no longer overshooting threshold. 
* FIXED: Compatibility adaptations for Sim Update 8. 


### Version 1.3.1 (September 5, 2021)
* FIXED: Interactive Pushback Audio no longer repeats commands. 
* FIXED: Localization now also works when installing via add-on manager. 
* FIXED: Version number in manifest is now correct. 
* IMPROVED: UI slider elements now take up full width of add-on window. 
* IMPROVED: German and Portuguese localization updated. 
* ADDED: New translation contributors added to credits. 
* ADDED: Option to enable / disable the Nosewheel Lift Simulation. 


### Version 1.3.0 (September 3, 2021)
* FIXED: Adjusted door buttons (fwd, aft, cargo) for Project Mega Pack Airbus A321. 
* IMPROVED: UI window can now be resized to smaller dimensions. 
* IMPROVED: Add-On package data updated with thumbnail for the FS Content Manager. 
* ADDED: Interactive Pushback Audio for airliner pushback procedure (experimental). 
    Note: Ground service comms phrases adapted for simulator use.
* ADDED: Add-On now waits for tug to be connected when Interactive Audio mode is enabled. 
* ADDED: Localization (translated by community) for the following languages: 
    Dutch, English (reference), French, German, Italian, Norwegian, Polish, 
    Portuguese, Russian, Spanish, Swedish 
* ADDED: Credits for all translations by the awesome community. THANK YOU! 
* ADDED: New option for Audio added to UI Options Tab. 

! Kudos to the awesome people who contributed their translations to Toolbar Pushback: 
Awesomeblack533 (Dutch), Pieter van 't Hof (Dutch), rmaure06 (French), DaStrobel (German), 
Maik (German), Picca (Italian), Ruben2097 (Italian), Papa (Norwegian), Maciej (Polish), 
Andre_sacheti (Portuguese), PreSuffix (Portuguese), Andrey (Russian), Alex G (Spanish), 
Antonio Blasco (Spanish), Bengt (Swedish) 


### Version 1.2.4 (August 20, 2021)
* FIXED: Sim Update 5 caused some fuel planner sliders to be hidden due to error in native simulator script (optionsListContent.js). 
* FIXED: UI buttons that were disabled could still be clicked after Sim Update 5. 
* IMPROVED: Catering truck will remain active until you dismiss the service. 
* IMPROVED: Baggage loader will remain active until you dismiss the service. 
* IMPROVED: Fuel truck will remain active until you close the fuel dialog. 
* IMPROVED: Stairs (ramp truck) now remain attached properly on all supported airliners. 
* IMPROVED: Pushback tug braking system has been revised. 
* IMPROVED: UI Tug Direction center line position corrected. 
* ADDED: New options for Ground Services added to UI Options Tab. 


### Version 1.2.3 (July 27, 2021)
* FIXED: Compatibility with Microsoft Flight Simulator version 1.18.13.0. 


### Version 1.2.2 (July 3, 2021)
* FIXED: Rudder malfunction after ending pushback procedure. 
* FIXED: Version number in add-on footer. 


### Version 1.2.1 (July 2, 2021)
* FIXED: Processes that could have caused frame rate fluctuations. 
* IMPROVED: Overall performance of the add-on features. 


### Version 1.2.0 (June 29, 2021)
* IMPROVED: Stairs will stay for as long as you want and don't drive away automatically (experimental). 
* IMPROVED: Now only right ctrl key + p will toggle UI window by default preventing keybind conflicts. 
* IMPROVED: Tug will now be released after aircraft has come to a full stop. 
* IMPROVED: Forward, Reverse and Hold button functionality has been revised. 
* IMPROVED: ATC pushback start and stop requests handling by Toolbar Pushback. 
* IMPROVED: Resizing both width and height of UI window is now possible. 
* IMPROVED: Pushback can no longer be invoked when airborne or taxiing. 
* IMPROVED: Door system automatically detects available doors. 
* ADDED: Change tug speed with mouse scroll wheel when hovering mouse over UI window. 
* ADDED: Changelog is now also included in the README file. 
* ADDED: Add-On automatically checks for updates and shows a notification. 
* ADDED: Options tab for custom user settings (more options will be added). 


### Version 1.1.0 (June 05, 2021) 
* FIXED: Ground Power Unit cable was stuck to FBW A32NX causing cabin pressure issues.
* FIXED: FBW A32NX parking brake state was not recognized after latest FBW update.
* FIXED: Fuel button was not working in some cases.
* FIXED: Stopping pushback via ATC did not always stop Toolbar Pushback.
* FIXED: Toolbar Pushback was usable after takeoff.
* IMPROVED: Aircraft door handling and support for 3rd party aircraft.
* ADDED: Toggle UI window with "ctrl + p".
* ADDED: "Hold" button on pushback tab for convenient stop and go.
* ADDED: Now "Parking Brake" button is available on pushback tab.


### Version 1.0.1 (May 23, 2021) 
Addressed the bugs and suggestions which have been reported:

* FIXED: Black screen after dialing down the tug speed to zero or switching directions.
* FIXED: UI elements misaligned on screen resolutions bigger than 1080p.
* IMPROVED: Added “Release Parking Brake” button to pushback window.
* ADDED: Two screenshots showing GA aircraft with small tug.


### Version 1.0.0 (May 23, 2021) 
Initial release. 


