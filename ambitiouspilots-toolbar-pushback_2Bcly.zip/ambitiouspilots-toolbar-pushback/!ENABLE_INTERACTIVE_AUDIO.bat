@echo off

:: This file will create symlinks to the English audio directory of Toolbar Pushback, 
:: so MSFS will be able to access these audio files when set to another language. This 
:: is to keep the download size of the add-on small, instead of duplicating the files 
:: for every language, as symlinks cannot be included in a zip file on Windows. 

set titleStr=Toolbar Pushback - Enable Interactive Pushback Audio
set curPath="%~dp0"
set path=Data\Shared\TBP\Sound

title %titleStr%

for /f "delims=\" %%a in ("%curPath%") do set curPath=%%~nxa

:PathCheck
if [%curPath%] == [ambitiouspilots-toolbar-pushback] (
	goto :Welcome
) else (
	echo ERROR: Make sure to run this file inside the "ambitiouspilots-toolbar-pushback" add-on directory and double check the name hasn't been modified. 
	echo.
	pause
)
goto :EOF

:Welcome
echo %titleStr%
echo.
echo Note: Running this batch file is only required if 
echo       you're using a language other than English 
echo       in Microsoft Flight Simulator. 
echo.
set /P choise=Do you want to continue? [Y/N] 
if /I "%choise%" == "Y" goto :EnableInteractiveAudio
if /I "%choise%" == "N" goto :Quit
goto :Welcome

:EnableInteractiveAudio
cls
echo %titleStr%
echo.
for %%L in ("de-DE", "es-ES", "fi-FI", "fr-FR", "it-IT", "ja-JP", "nb-NO", "nl-NL", "pl-PL", "pt-BR", "ru-RU", "sv-SE", "zh-CN") do (
	echo Creating symlink for language %%~L
	mklink /J ".\%path%\%%~L" ".\%path%\en-US" > nul 2>&1
)
echo Done.
echo.
echo Enjoy Interactive Pushback Audio with Toolbar Pushback.
goto :End

:End
echo.
pause

:Quit
exit